#spill prosjekt 

Skyte spill som er laget med pygame

Må gjøre:

- [x] Skisse
- [x] Fikse sekunder og poeng/liv
- [x]Få ikonene mindre
- [x]Få de til å skyte både opp 
- [x]Miste liv/ dø
- [ ]lage en meny
- [x]fikse opp i skudd.py
