from sang import Sang

class Spilleliste():
    def __init__(self, navn: str, sanger: list):
        self.navn = navn
        self.sanger = []

    def legg_til_sanger(self, tittel):
        self.sanger.append(tittel)

    def lengde(self):
        return self.sanger

    def spill_alle(spill):
        return spill 

    def tittel_i_liste():
        #lag en if setning der jeg returnerer om den er i listen eller ikke
        #litt som lyspære oppgaven
        pass

    def artistliste():
        #lage en if setning om at hvis artisten er der 2 >= så printer den alle sangene personen har vært med i
        pass
        


